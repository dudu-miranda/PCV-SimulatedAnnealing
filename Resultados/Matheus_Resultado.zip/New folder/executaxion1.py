#!/usr/bin/python
# -- coding: utf-8 --

from main import *

nome_arquivo="frb56-25-1"
nome_arquivo_entrada = nome_arquivo+".txt"
nome_arquivo_saida	 = "result1_"+nome_arquivo+".txt"

f=open(nome_arquivo_saida,'w')
f.write("Nome_arquivo\tTemperatura_inicial\tSAMAX\tQtd_Reaquecimentos\tMetodo_Vizinho\tFuncao_Objetivo\tIteracao\n")
temp_inicial = 100
Samax = 10

for i in range(1,3):
	metodo_inicial = i
	for j in range(7,15,7):
		n_reaquecer = j
		for k in range(1,3):
			metodo_vizinho = k
			for l in range(1,11):
				iter = l
				string =  main(metodo_inicial,n_reaquecer,metodo_vizinho,nome_arquivo_entrada,temp_inicial,Samax)
				string += str(iter)+"\n"
				f.write(string)



'''

for i in range(1,4):
	metodo_inicial = i
	for j in range(100,201,50):
		temperatura_max = j
		for k in range(15,26,5):
			SAMAX = k
			for l in range(7,22,7):
				n_reaquecimento = l
				for m in range(0,2):
					reseta_inicial = m
					for n in range(1,3):
						metodo_vizinho = n
						for o in range(1, 2):
							iter = o
							string = main(metodo_inicial,temperatura_max,SAMAX,n_reaquecimento,reseta_inicial,metodo_inicial,nome_arquivo_entrada)
							string += str(iter)+"\n"
							f.write(string)

'''

f.close()
																				

